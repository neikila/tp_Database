java -jar DBApi-1.0-jar-with-dependencies.jar
